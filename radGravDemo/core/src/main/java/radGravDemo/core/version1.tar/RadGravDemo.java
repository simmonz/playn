package radGravDemo.core;

import react.Slot;
import react.Value;

import org.jbox2d.common.Vec2;
import org.jbox2d.dynamics.World;
import org.jbox2d.dynamics.BodyDef;
import org.jbox2d.dynamics.Body;
import org.jbox2d.dynamics.BodyType;
import org.jbox2d.dynamics.FixtureDef;
import org.jbox2d.dynamics.Fixture;
import org.jbox2d.collision.shapes.PolygonShape;
import org.jbox2d.collision.shapes.CircleShape;
import org.jbox2d.callbacks.ContactListener;
import org.jbox2d.callbacks.DebugDraw;
import org.jbox2d.dynamics.contacts.Contact;
import org.jbox2d.callbacks.ContactImpulse;
import org.jbox2d.collision.Manifold;
//import org.jbox2d.collision.shapes.EdgeShape;
import org.jbox2d.dynamics.joints.DistanceJointDef;

import pythagoras.f.IDimension;

import playn.core.Image;
import playn.scene.Layer;
import playn.core.Platform;
import playn.core.Surface;
import playn.core.Tile;
import playn.scene.ImageLayer;
import playn.scene.GroupLayer;
import playn.scene.SceneGame;
import playn.core.Clock;
import playn.scene.LayerUtil;
import playn.core.DebugDrawBox2D;
import playn.core.Keyboard;
import playn.core.Font;
import playn.core.TextBlock;
import playn.core.TextFormat;
import playn.core.TextLayout;
import playn.core.TextWrap;
import playn.core.Canvas;
import playn.scene.CanvasLayer;

import java.util.List;
import java.util.ArrayList;

public class RadGravDemo extends SceneGame {

  // dimensions of the physical universe 
  // sceneWidth and sceneHeight are already determined. Just set physWidth, then physHeight will
  // be calculated so that circles, etc., in physical coords get mapped to circles in Scene coords.
  protected static float physWidth = 40, physHeight, sceneWidth, sceneHeight;

  // multiply by this to convert from physical dimensions to playn scene dimensions
  protected static float scalePhysToScene; 

  // scales and accounts for the fact that Jbox2D has the y-axis pointing up.
  protected static Vec2 toSceneCoords (Vec2 physicsCoords) {
    return new Vec2(scalePhysToScene * physicsCoords.x, sceneHeight - scalePhysToScene * physicsCoords.y);
  }

  // Jbox2D physics world
  protected final World world;

  private boolean showDebugGraphics = false;

  // This list holds the ship and planets
  protected final List<RemovableEntity> universeObjects = new ArrayList<>(); 

  // gaveOver and startScreen are reactive values
  protected static final Value<Boolean> gameOver = Value.create(true);
  protected static final Value<Boolean> startScreen = Value.create(true);

  public RadGravDemo (final Platform plat) {
    super(plat, 33); // update our "simulation" 33ms (30 times per second)

    final IDimension screenSize = plat.graphics().viewSize;
    sceneWidth = screenSize.width();
    sceneHeight = screenSize.height();
    scalePhysToScene = sceneWidth/physWidth;
    physHeight = sceneHeight/scalePhysToScene;

    rootLayer.add(new Layer() {
      protected void paintImpl (Surface surf) {
        surf.setFillColor(0xFFF8F8F8).fillRect(0, 0, sceneWidth, sceneHeight);
      }
    });

    Vec2 gravity = new Vec2(0f, 0f);
    world = new World(gravity);

    final GroupLayer universeLayer = new GroupLayer(); 
    //universeLayer.setScale(lambda * sceneWidth, lambda * sceneHeight);
    rootLayer.add(universeLayer);
    
    // add a planet
    universeObjects.add(new Planet(plat, universeLayer, world, new Vec2(physWidth/5, physHeight/6), 4f));

    // add a ship
    universeObjects.add(new Ship(plat, universeLayer, world, new Vec2(physWidth/5, physHeight/4)));


    // make a game begin layer with some text in it. 
    StringBuilder beginMsg = new StringBuilder();
    beginMsg.append("Use the left, right, and up keys\n\n to steer your ship.\n\n Hit 'b' to begin."); 
    TextBlock beginBlock = new TextBlock(plat.graphics().layoutText(
          beginMsg.toString(), 
          new TextFormat(new Font("Helvetica", Font.Style.BOLD, 30)),
          TextWrap.MANUAL));
    final Canvas beginCanvas = plat.graphics().createCanvas(beginBlock.bounds.width()+2, beginBlock.bounds.height());
    beginCanvas.setFillColor(0xFF0000f8);
    beginBlock.fill(beginCanvas, TextBlock.Align.CENTER, 2, 2);
    final CanvasLayer beginLayer = new CanvasLayer(plat.graphics(), beginCanvas);

    startScreen.connect(new Slot<Boolean> () {
      @Override public void onEmit(Boolean starting) {  
        if (starting) {
          Vec2 middle = toSceneCoords(new Vec2(physWidth/2, physHeight/2));
          rootLayer.addCenterAt(beginLayer, middle.x, middle.y+1f);
        }
        else {
          rootLayer.remove(beginLayer);
        }
      }
    });

    startScreen.updateForce(true);

    plat.input().keyboardEvents.connect(new Keyboard.KeySlot() {
      @Override public void onEmit (Keyboard.KeyEvent event) {
        if (event.down && gameOver.get()) {
          switch (event.key) {
            case R: 
              gameOver.update(false);
              break;
            case B: 
              startScreen.update(false);
              break;
            default: break;
          } 
        }
      }
    });

    // make a game over layer with some text in it. 
    StringBuilder msg = new StringBuilder();
    msg.append("Fuel is necessary for\nspace travel\nbut you are out of it!\n\nYou may want to\nadmit failure!\nPress 'r' to restart."); 

    TextBlock block = new TextBlock(plat.graphics().layoutText(
          msg.toString(), 
          new TextFormat(new Font("Helvetica", Font.Style.BOLD, 30)),
          TextWrap.MANUAL));
    final Canvas textcanvas = plat.graphics().createCanvas(block.bounds.width()+2, block.bounds.height());
    textcanvas.setFillColor(0xFF0000f8);
    block.fill(textcanvas, TextBlock.Align.CENTER, 2, 2);
    final CanvasLayer gameOverLayer = new CanvasLayer(plat.graphics(), textcanvas);

    // create a listener for the gameOver signal
    gameOver.connect(new Slot<Boolean> () {
      @Override public void onEmit(Boolean over) {  
        if (over) {
          Vec2 point = toSceneCoords(new Vec2(physWidth/2, 2*physHeight/3));
          rootLayer.addCenterAt(gameOverLayer, point.x, point.y);
        }
        else {
          rootLayer.remove(gameOverLayer);
          for (RemovableEntity entity : universeObjects) 
            entity.remove();
          universeObjects.clear();
          universeLayer.disposeAll();
          // add a planet
          universeObjects.add(new Planet(plat, universeLayer, world, new Vec2(physWidth/5, physHeight/6), 4f));
          // add a ship
          universeObjects.add(new Ship(plat, universeLayer, world, new Vec2(physWidth/5, physHeight/4)));
        }
      }
    });

    // set DebugDraw
    /*
    final DebugDrawBox2D debugDraw;  
    final ImageLayer debugLayer;

    debugDraw = new DebugDrawBox2D(plat, (int) screenSize.width(), (int) screenSize.height());
    debugDraw.setFlipY(true);
    debugDraw.setStrokeAlpha(150);
    debugDraw.setFillAlpha(75);
    debugDraw.setStrokeWidth(2.0f);
    debugDraw.setFlags(DebugDraw.e_shapeBit | DebugDraw.e_jointBit | DebugDraw.e_aabbBit | DebugDraw.e_centerOfMassBit);
    debugDraw.setCamera(0, physHeight, scalePhysToScene);
    rootLayer.add(debugLayer = new ImageLayer(debugDraw.canvas.image));
    world.setDebugDraw(debugDraw);
    */

    update.connect(new Slot<Clock>() {
      @Override public void onEmit (Clock clock) {
        world.step(clock.dt/500f, 10,10);
        for (MovingEntity entity : universeObjects) 
          entity.update();
      }
    });

    paint.connect(new Slot<Clock>() {
      @Override public void onEmit (Clock clock) {
        //debugDraw.canvas.clear();
        //world.drawDebugData();
        //debugLayer.tile().texture().update(debugDraw.canvas.image);
        for (MovingEntity entity : universeObjects) 
          entity.paint(clock);
      }
    });
  }
}
